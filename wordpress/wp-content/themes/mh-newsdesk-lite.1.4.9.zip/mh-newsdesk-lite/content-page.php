<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php mh_newsdesk_lite_page_title(); ?>
	</header>
	<div class="entry-content mh-clearfix">
		<?php the_content(); ?>
	</div>
</article>