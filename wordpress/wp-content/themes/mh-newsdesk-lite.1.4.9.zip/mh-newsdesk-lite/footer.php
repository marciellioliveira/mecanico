</div>
<footer class="mh-footer">
	<div class="wrapper-inner">
		<p class="copyright"><?php printf(__('Copyright %1$s | MH Newsdesk lite by %2$s', 'mh-newsdesk-lite'), date("Y"), '<a href="' . esc_url('https://www.mhthemes.com/') . '" rel="nofollow">MH Themes</a>'); ?></p>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>